Version de test pour le magasin (WIP)

Shop
- Un stage moche (je réserve la refonte visuelle pour la toute fin)
- Création de l'inventaire en fonction des morceaux disponibles (serveur)
- Regarde la setliste pour savoir combien de morceau le public doit acheter
- Ajuste les prix en conséquence (perfectible mais fonctionne)
- Injecte les morceaux achetés dans la setliste (attention si il y a un slot libre avant le magasin, il partira en arrière)
- Séquence dialogue/achat (placeholders pour les dialogues)

Autres
- Maintenant unity devrait s'initialiser correctement au démarrage (concert state)
- Appuyer sur L pour des infos de connexion diverses